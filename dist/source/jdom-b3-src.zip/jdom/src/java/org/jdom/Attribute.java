/*-- 

 Copyright (C) @year@ Brett McLaughlin & Jason Hunter. All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modifica-
 tion, are permitted provided that the following conditions are met:
 
 1. Redistributions of source code must retain the above copyright notice,
    this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions, the disclaimer that follows these conditions,
    and/or other materials provided with the distribution.
 
 3. The names "JDOM" and "Java Document Object Model" must not be used to
    endorse or promote products derived from this software without prior
    written permission. For written permission, please contact
    license@jdom.org.
 
 4. Products derived from this software may not be called "JDOM", nor may
    "JDOM" appear in their name, without prior written permission from the
    JDOM Project Management (pm@jdom.org).
 
 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS  FOR A PARTICULAR  PURPOSE ARE  DISCLAIMED.  IN NO  EVENT SHALL  THE
 JDOM PROJECT  OR ITS CONTRIBUTORS  BE LIABLE FOR  ANY DIRECT, INDIRECT, 
 INCIDENTAL, SPECIAL,  EXEMPLARY, OR CONSEQUENTIAL  DAMAGES (INCLUDING, BUT 
 NOT LIMITED TO, PROCUREMENT  OF SUBSTITUTE GOODS OR SERVICES; LOSS
 OF USE, DATA, OR  PROFITS; OR BUSINESS  INTERRUPTION)  HOWEVER CAUSED AND ON
 ANY  THEORY OF LIABILITY,  WHETHER  IN CONTRACT,  STRICT LIABILITY,  OR TORT
 (INCLUDING  NEGLIGENCE OR  OTHERWISE) ARISING IN  ANY WAY OUT OF THE  USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 
 This software  consists of voluntary contributions made  by many individuals
 on  behalf of the Java Document Object Model Project and was originally 
 created by Brett McLaughlin <brett@jdom.org> and 
 Jason Hunter <jhunter@jdom.org>. For more  information on the JDOM 
 Project, please see <http://www.jdom.org/>.
 
 */
package org.jdom;

/**
 * <p><code>Attribute</code> defines behavior for an XML 
 *   attribute, modeled in Java.  Methods allow the user 
 *   to obtain the value of the attribute as well as 
 *   namespace information.
 * </p>
 * 
 * @author <a href="mailto:brett@jdom.org">Brett McLaughlin</a>
 * @author <a href="mailto:jhunter@jdom.org">Jason Hunter</a>
 * @version 1.0
 */
public class Attribute {

    /** The local name of the <code>Attribute</code> */
    protected String name;

    /** The namespace prefix of the <code>Attribute</code> */
    protected String prefix;

    /** The value of the <code>Attribute</code> */
    protected String value;

    /**
     * <p>
     * Default, no-args constructor for implementations
     *   to use if needed.
     * </p>
     */
    protected Attribute() {}

    /**
     * <p>
     * This will create a new <code>Attribute</code> with the
     *   specified name and value.
     * </p>
     *
     * @param prefix <code>String</code> prefix for <code>Attribute</code>.
     * @param name <code>String</code> local name of <code>Attribute</code>.
     * @param value <code>String</code> value for new attribute.
     * @return <code>Attribute</code> - created <code>Attribute</code>.
     */    
    public Attribute(String prefix, String name, String value) {
        this.prefix = prefix;
        this.name = name;
        this.value = value;
    }

    /**
     * <p>
     * This will create a new <code>Attribute</code> with the
     *   specified name and value.
     * </p>
     *
     * @param fullName <code>String</code> name of <code>Attribute</code>.
     * @param value <code>String</code> value for new attribute.
     * @return <code>Attribute</code> - created <code>Attribute</code>.
     */
    public Attribute(String name, String value) {
        int split = name.indexOf(":");
        if (split < 0) {
            this.prefix = "";
            this.name = name;
            this.value = value;
        } else {
            if (!name.startsWith(":")) {
                this.prefix = name.substring(0, split);
            } else {
                prefix = "";
            }
            this.name = name.substring(split+1);
            this.value = value;
        }
    }

    /**
     * <p>
     * This will retrieve the local name of the 
     *   <code>Attribute</code>. For any XML attribute 
     *   which appears as 
     *   <code>[namespacePrefix]:[attributeName]</code>,
     *   the local name of the attribute would be 
     *   <code>[attributeName]</code>. When the attribute 
     *   has no namespace prefix (and is in the default
     *   namespace), the local name is simply the attribute 
     *   name.
     * </p><p>
     * To obtain the namespace prefix for this 
     *   attribute, the
     *   <code>{@link #getNamespacePrefix()}</code>
     *   method should be used.
     * </p>
     *
     * @return <code>String</code> - name of this attribute, 
     *                               without any namespace prefix.
     */
    public String getName() {
        return name;
    }

    /**
     * <p>
     * This will retrieve the full name of the <code>Attrbute</code>. 
     *   For any XML attribute whose name is
     *   <code>[namespacePrefix]:[elementName]</code>,
     *   the full name of the attribute would be 
     *   everything (both namespace prefix and
     *   element name). When the attribute has no 
     *   namespace prefix (and is in the default
     *   namespace), the full name is simply the attribute's
     *   local name.
     * </p><p>
     * To obtain the local name of the attribute, the
     *   <code>{@link #getName()}</code> method should be used.
     * </p><p>
     * To obtain the namespace prefix for this attribute, 
     *   the <code>{@link #getNamespacePrefix()}</code>
     *   method should be used.
     * </p>
     *
     * @return <code>String</code> - full name for this element.
     */
    public String getFullName() {
        StringBuffer buf = new StringBuffer();
        if (prefix != null && !prefix.equals("")) {
            buf.append(prefix)
            .append(":");
        }
        buf.append(name);
        return buf.toString();
    }

    /**
     * <p>
     * This will retrieve the namespace prefix of the 
     *   <code>Attribute</code>. For any XML attribute 
     *   which appears as 
     *   <code>[namespacePrefix]:[attributeName]</code>,
     *   the namespace prefix of the attribute would be 
     *   <code>[namespacePrefix]</code>. When the attribute 
     *   has no namespace prefix (and is in the default
     *   namespace), an empty <code>String</code> is returned.
     * </p>
     *
     * @return <code>String</code> - namespace prefix of this 
     *                               attribute.
     */    
    public String getNamespacePrefix() {
        return prefix;
    }

    /**
     * <p>
     * This will return the actual textual value of this 
     *   <code>Attribute</code>.  This will include all text 
     *   within the quotation marks.
     * </p>
     *
     * @return <code>String</code> - value for this attribute.
     */
    public String getValue() {
        return value;
    }

    /**
     * <p>
     * This will set the value of the <code>Attribute</code>.
     * </p>
     *
     * @param value <code>String</code> value for the attribute.
     */
    public void setValue(String value) {
        this.value = value;
    }

    /////////////////////////////////////////////////////////////////
    // Convenience Methods below here
    /////////////////////////////////////////////////////////////////

    /**
     * <p>
     * This will return the actual textual value of this 
     *   <code>Attribute</code>.  This will include all text 
     *   within the quotation marks.  If no value exists, the
     *   supplied default value will be returned.
     * </p>
     *
     * @param defaultValue <code>String</code> default value.
     * @return <code>String</code> - value for this attribute.
     */
    public String getValue(String defaultValue) {
        if ((value != null) && (!value.equals(""))) {
            return value;
        }
        return defaultValue;
    }

    /**
     * <p>
     * This gets the value of the attribute, in
     *   <code>int</code> form, and if no conversion
     *   can occur, returns the supplied default
     *   value.
     * </p>
     *
     * @param defaultValue <code>int</code> default.
     * @return <code>int</code> value of attribute.
     */
    public int getIntValue(int defaultValue) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    /**
     * <p>
     * This gets the value of the attribute, in
     *   <code>int</code> form, and if no conversion
     *   can occur, throws a
     *   <code>{@link DataConversionException}</code>
     * </p>
     *
     * @return <code>int</code> value of attribute.
     * @throws <code>DataConversionException</code> - when conversion fails.
     */    
    public int getIntValue() throws DataConversionException {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            throw new DataConversionException(name, "int");
        }
    }

    /**
     * <p>
     * This gets the value of the attribute, in
     *   <code>long</code> form, and if no conversion
     *   can occur, returns the supplied default
     *   value.
     * </p>
     *
     * @param defaultValue <code>long</code> default.
     * @return <code>long</code> value of attribute.
     */    
    public long getLongValue(long defaultValue) {
        try {
            return Long.parseLong(value);
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    /**
     * <p>
     * This gets the value of the attribute, in
     *   <code>long</code> form, and if no conversion
     *   can occur, throws a
     *   <code>{@link DataConversionException}</code>
     * </p>
     *
     * @return <code>long</code> value of attribute.
     * @throws <code>DataConversionException</code> - when conversion fails.     
     */        
    public long getLongValue() throws DataConversionException {
        try {
            return Long.parseLong(value);
        } catch (NumberFormatException e) {
            throw new DataConversionException(name, "long");
        }
    } 

    /**
     * <p>
     * This gets the value of the attribute, in
     *   <code>float</code> form, and if no conversion
     *   can occur, returns the supplied default
     *   value.
     * </p>
     *
     * @param defaultValue <code>float</code> default.
     * @return <code>float</code> value of attribute.    
     */    
    public float getFloatValue(float defaultValue) {
        try {
            return Float.parseFloat(value);
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    /**
     * <p>
     * This gets the value of the attribute, in
     *   <code>float</code> form, and if no conversion
     *   can occur, throws a
     *   <code>{@link DataConversionException}</code>
     * </p>
     *
     * @return <code>float</code> value of attribute.
     * @throws <code>DataConversionException</code> - when conversion fails.     
     */        
    public float getFloatValue() throws DataConversionException {
        try {
            return Float.parseFloat(value);
        } catch (NumberFormatException e) {
            throw new DataConversionException(name, "float");
        }
    }

    /**
     * <p>
     * This gets the value of the attribute, in
     *   <code>double</code> form, and if no conversion
     *   can occur, returns the supplied default
     *   value.
     * </p>
     *
     * @param defaultValue <code>double</code> default.
     * @return <code>double</code> value of attribute.
     */    
    public double getDoubleValue(double defaultValue) {
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    /**
     * <p>
     * This gets the value of the attribute, in
     *   <code>double</code> form, and if no conversion
     *   can occur, throws a
     *   <code>{@link DataConversionException}</code>
     * </p>
     *
     * @return <code>double</code> value of attribute.
     * @throws <code>DataConversionException</code> - when conversion fails.     
     */        
    public double getDoubleValue() throws DataConversionException {
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException e) {
            throw new DataConversionException(name, "double");
        }
    }

    /**
     * <p>
     * This gets the value of the attribute, in
     *   <code>boolean</code> form, and if no conversion
     *   can occur, returns the supplied default
     *   value.
     * </p>
     *
     * @param defaultValue <code>boolean</code> default.
     * @return <code>boolean</code> value of attribute.
     */    
    public boolean getBooleanValue(boolean defaultValue) {
        if ((value.equalsIgnoreCase("true")) ||
            (value.equalsIgnoreCase("on")) ||
            (value.equalsIgnoreCase("yes"))) {
            return true;
        } else if ((value.equalsIgnoreCase("false")) ||
                   (value.equalsIgnoreCase("off")) ||
                   (value.equalsIgnoreCase("no"))) {
            return false;
        } else {
            return defaultValue;            
        }
    }    

    /**
     * <p>
     * This gets the value of the attribute, in
     *   <code>boolean</code> form, and if no conversion
     *   can occur, throws a
     *   <code>{@link DataConversionException}</code>
     * </p>
     *
     * @return <code>boolean</code> value of attribute.
     * @throws <code>DataConversionException</code> - when conversion fails.     
     */        
    public boolean getBooleanValue() throws DataConversionException {
        if ((value.equalsIgnoreCase("true")) ||
            (value.equalsIgnoreCase("on")) ||
            (value.equalsIgnoreCase("yes"))) {
            return true;
        } else if ((value.equalsIgnoreCase("false")) ||
                   (value.equalsIgnoreCase("off")) ||
                   (value.equalsIgnoreCase("no"))) {
            return false;
        } else {
            throw new DataConversionException(name, "boolean");            
        }
    }
    
    /**
     * <p>
     * This gets the value of the attribute, in
     *   <code>char</code> form, and if no conversion
     *   can occur, returns the supplied default
     *   value.
     * </p>
     *
     * @return <code>char</code> value of attribute.
     * @throws <code>DataConversionException</code> - when conversion fails.     
     */        
    public char getCharValue(char defaultValue) {
        try {
            return value.charAt(0);
        } catch (Exception e) {
            return defaultValue;
        }
    }    

    /**
     * <p>
     * This gets the value of the attribute, in
     *   <code>char</code> form, and if no conversion
     *   can occur, throws a
     *   <code>{@link DataConversionException}</code>
     * </p>
     *
     * @return <code>char</code> value of attribute.
     * @throws <code>DataConversionException</code> - when conversion fails.     
     */        
    public char getCharValue() throws DataConversionException {
        try {
            return value.charAt(0);
        } catch (Exception e) {
            throw new DataConversionException(name, "char");
        }
    }

    /**
     * <p>
     * This gets the value of the attribute, in
     *   <code>byte</code> form, and if no conversion
     *   can occur, returns the supplied default
     *   value.
     * </p>
     *
     * @param defaultValue <code>byte</code> default.
     * @return <code>byte</code> value of attribute.
     */    
    public byte getByteValue(byte defaultValue) {
        try {
            return Byte.parseByte(value);
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    /**
     * <p>
     * This gets the value of the attribute, in
     *   <code>byte</code> form, and if no conversion
     *   can occur, throws a
     *   <code>{@link DataConversionException}</code>
     * </p>
     *
     * @return <code>byte</code> value of attribute.
     * @throws <code>DataConversionException</code> - when conversion fails.     
     */        
    public byte getByteValue() throws DataConversionException {
        try {
            return Byte.parseByte(value);
        } catch (NumberFormatException e) {
            throw new DataConversionException(name, "byte");
        }
    }    

}










