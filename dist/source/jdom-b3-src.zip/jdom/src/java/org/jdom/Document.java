/*-- 

 Copyright (C) @year@ Brett McLaughlin & Jason Hunter. All rights reserved.
 
 Redistribution and use in source and binary forms, with or without modifica-
 tion, are permitted provided that the following conditions are met:
 
 1. Redistributions of source code must retain the above copyright notice,
    this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions, the disclaimer that follows these conditions,
    and/or other materials provided with the distribution.
 
 3. The names "JDOM" and "Java Document Object Model" must not be used to
    endorse or promote products derived from this software without prior
    written permission. For written permission, please contact
    license@jdom.org.
 
 4. Products derived from this software may not be called "JDOM", nor may
    "JDOM" appear in their name, without prior written permission from the
    JDOM Project Management (pm@jdom.org).
 
 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS  FOR A PARTICULAR  PURPOSE ARE  DISCLAIMED.  IN NO  EVENT SHALL  THE
 JDOM PROJECT  OR ITS CONTRIBUTORS  BE LIABLE FOR  ANY DIRECT, INDIRECT, 
 INCIDENTAL, SPECIAL,  EXEMPLARY, OR CONSEQUENTIAL  DAMAGES (INCLUDING, BUT 
 NOT LIMITED TO, PROCUREMENT  OF SUBSTITUTE GOODS OR SERVICES; LOSS
 OF USE, DATA, OR  PROFITS; OR BUSINESS  INTERRUPTION)  HOWEVER CAUSED AND ON
 ANY  THEORY OF LIABILITY,  WHETHER  IN CONTRACT,  STRICT LIABILITY,  OR TORT
 (INCLUDING  NEGLIGENCE OR  OTHERWISE) ARISING IN  ANY WAY OUT OF THE  USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 
 This software  consists of voluntary contributions made  by many individuals
 on  behalf of the Java Document Object Model Project and was originally 
 created by Brett McLaughlin <brett@jdom.org> and 
 Jason Hunter <jhunter@jdom.org>. For more  information on the JDOM 
 Project, please see <http://www.jdom.org/>.
 
 */
package org.jdom;

import java.util.LinkedList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.List;

/**
 * <p>
 * <code>Document</code> defines behavior for an XML Document, modeled 
 *   in Java.  Methods allow the user to the root element as well
 *   as processing instructions and other document-level information.
 * </p>
 *
 * @author <a href="mailto:brett@jdom.org">Brett McLaughlin</a>
 * @author <a href="mailto:jhunter@jdom.org">Jason Hunter</a>
 * @version 1.0 
 */
public class Document {

    /**
     * <code>{@link ProcessingInstruction}</code>s of 
     *   <code>Document</code>, with order preserved. 
     *   These are stored at the document level, so while 
     *   order is consistent, placement is not.  In
     *   other words the resulting <code>Document</code> is 
     *   the same functionally as when created, but not 
     *   neccessarily lexically.
     */
    protected List processingInstructions;

    /**
     * This <code>Document</code>'s 
     *   <code>{@link Comment}</code>s and
     *   the root <code>{@link Element}</code>
     */
    protected List content;

    /**
     * The namespace prefix/URI mappings for this
     *   <code>Document</code>.
     */
    protected Map namespaceMappings;

    /** 
     * The root <code>{@link Element}</code> 
     *   of the <code>Document</code>. 
     */
    protected Element rootElement;

    /** The <code>{@link DocType}</code> declaration */
    protected DocType docType;

    /**
     * <p>
     * Default, no-args constructor for implementations
     *   to use if needed.
     * </p>
     */
    protected Document() {}

    /**
     * <p>
     * This will create a new <code>Document</code>,
     *   with the supplied <code>{@link Element}</code> 
     *   as the root element and the supplied 
     *   <code>{@link DocType}</code> declaration.
     * </p>
     *
     * @param rootElement <code>Element</code> for document root.
     * @param docType <code>DocType</code> declaration.
     */    
    public Document(Element rootElement, DocType docType) {
        this.rootElement = rootElement;
        this.docType = docType;
        processingInstructions = new LinkedList();
        content = new LinkedList();
        namespaceMappings = new HashMap();        

        if (rootElement != null) {
            content.add(rootElement);
            for (Iterator i = namespaceMappings.keySet().iterator(); i.hasNext(); ) {
                String prefix = (String)i.next();
                String attValue = (String)namespaceMappings.get(prefix);
                rootElement.addAttribute(new Attribute("xmlns", prefix, attValue));
            }
        }
    }

    /**
     * <p>
     * This will create a new <code>Document</code>,
     *   with the supplied <code>{@link Element}</code> 
     *   as the root element, and no <code>{@link DocType}</code>
     *   declaration.
     * </p>
     *
     * @param rootElement <code>Element</code> for document root
     */   
    public Document(Element rootElement) {
        this(rootElement, null);
    }     

    /**
     * <p>
     * This will return the root <code>Element</code> 
     *   for this <code>Document</code>, or null if there is none.
     * </p>
     *
     * @return <code>Element</code> - the document's root element
     * @throws <code>NoSuchElementException</code> - when no root 
     *                                      element exists.
     */
    public Element getRootElement() throws NoSuchElementException {
        if (rootElement == null)  {
            throw new NoSuchElementException("No root element exists.");
        }
        return rootElement;
    }

    /**
     * <p>
     * This sets the root <code>{@link Element}</code> for the
     *   <code>Document</code>.
     * </p>
     *
     * @param rootElement <code>Element</code> to be new root.
     * @return <code>Document</code> - modified Document.
     */
    public Document setRootElement(Element rootElement) {
        this.rootElement = rootElement;

        if (rootElement != null) {
            content.add(rootElement);
            for (Iterator i = namespaceMappings.keySet().iterator(); i.hasNext(); ) {
                String prefix = (String)i.next();
                String attValue = (String)namespaceMappings.get(prefix);
                rootElement.addAttribute(new Attribute("xmlns", prefix, attValue));
            }
        }

        return this;
    }

    /**
     * <p>
     * This will return the <code>{@link DocType}</code>
     *   declaration for this <code>Document</code>, or
     *   <code>null</code> if none exists.
     * </p>
     *
     * @return <code>DocType</code> - the DOCTYPE declaration.
     */
    public DocType getDocType() {
        return docType;
    }

    /**
     * <p>
     * This will set the <code>{@link DocType}</code>
     *   declaration for this <code>Document</code>.
     * </p>
     *
     * @param docType <code>DocType</code> declaration.
     */
    public Document setDocType(DocType docType) {
        this.docType = docType;

        return this;
    }

    /**
     * <p> 
     * This will return the list of
     *   <code>{@link ProcessingInstruction}</code>s
     *   for this <code>Document</code>.
     * </p>
     *
     * @return <code>List</code> - PIs for document.
     */    
    public List getProcessingInstructions() {
        return processingInstructions;
    }

    /**
     * <p>
     * This returns the processing instructions for this
     *   <code>Document</code> which have the supplied target.
     * </p>
     *
     * @param target <code>String</code> target of PI to return.
     * @return <code>List</code> - all PIs with the specified
     *         target.
     */
    public List getProcessingInstructions(String target) {
        PartialList pis = new PartialList(processingInstructions);

        Iterator i = processingInstructions.iterator();
        while (i.hasNext()) {
            ProcessingInstruction pi = 
            (ProcessingInstruction)i.next();                
            if (pi.getTarget().equals(target)) {
                pis.addPartial(pi);
            }
        }

        return pis;
    }

    /**
     * <p>
     * This returns the first processing instruction for this
     *   <code>Document</code> for the supplied target.
     * </p>
     *
     * @param target <code>String</code> target of PI to return.
     * @return <code>ProcessingInstruction</code> - the first PI
     *         with the specified target.
     */
    public ProcessingInstruction getProcessingInstruction(String target)
        throws NoSuchProcessingInstructionException {

        Iterator i = processingInstructions.iterator();
        while (i.hasNext()) {
            ProcessingInstruction pi = 
            (ProcessingInstruction)i.next();                
            if (pi.getTarget().equals(target)) {
                return pi;
            }
        }

        // If we got here, none found
        throw new NoSuchProcessingInstructionException(target);
    }

    /**
     * <p>
     * </p>
     *
     * @param pi the PI to add.
     * @return <code>Document</code> this document modified.
     */
    public Document addProcessingInstruction(ProcessingInstruction pi) {
        processingInstructions.add(pi);

        return this;
    }

    /**
     * <p>
     * </p>
     *
     * @param target target of PI to add.
     * @param data raw data portion of PI to add.
     * @return <code>Document</code> this document modified.
     */
    public Document addProcessingInstruction(String target, String data) {
        processingInstructions.add(new ProcessingInstruction(target, data));

        return this;
    }

    /**
     * <p>
     * </p>
     *
     * @param target target of PI to add.
     * @param data map data portion of PI to add.
     * @return <code>Document</code> this document modified.
     */
    public Document addProcessingInstruction(String target, Map data) {
        processingInstructions.add(new ProcessingInstruction(target, data));

        return this;
    }

    /**
     * <p>
     * This sets the PIs for this <code>Document</code> to those in the
     *   <code>List</code supplied (removing all other PIs).
     * </p>
     *
     * @param processingInstructions <code>List</code> of PIs to use.
     * @return <code>Document</code> - this Document modified.
     */
    public Document setProcessingInstructions(
        List processingInstructions) {

        this.processingInstructions = processingInstructions;
        return this;
    }

    /**
     * <p>
     * This will remove the specified <code>ProcessingInstruction</code>.
     * </p>
     *
     * @param processingInstruction <code>ProcessingInstruction</code>
     *                              to remove.
     * @return <code>boolean</code> - whether the requested PI was removed.
     */
    public boolean removeProcessingInstruction(
                                              ProcessingInstruction processingInstruction) {

        return processingInstructions.remove(
                                            processingInstruction);
    }

    /**
     * <p>
     * This will remove the first PI with the specified target.
     * </p>
     *
     * @param target <code>String</code> target of PI to remove.
     * @return <code>boolean</code> - whether the requested PI was removed.
     */
    public boolean removeProcessingInstruction(String target) {

        try {
            return processingInstructions.remove(
                                                getProcessingInstruction(target));
        } catch (NoSuchProcessingInstructionException e) {
            return false;
        }
    }

    /**
     * <p>
     * This will remove all PIs with the specified target.
     * </p>
     *
     * @param target <code>String</code> target of PI to remove.
     * @return <code>boolean</code> - whether the requested PIs were removed.
     */
    public boolean removeProcessingInstructions(String target) {
        boolean deletedSome = false;

        Iterator i = processingInstructions.iterator();
        while (i.hasNext()) {
            ProcessingInstruction pi = 
            (ProcessingInstruction)i.next();                
            if (pi.getTarget().equals(target)) {
                i.remove();
            }
        }

        return deletedSome;
    }

    /**
     * <p>
     * Adds a namespace prefix/URI mapping.
     * </p>
     *
     * @param prefix <code>String</code> prefix for mapping.
     * @param uri <code>String</code> URI being mapped to
     * @return <code>Document</code> - this modified
     */
    public Document addNamespaceMapping(String prefix, String mapping) {
        namespaceMappings.put(prefix, mapping);
        if (rootElement != null) {
            rootElement.addAttribute(new Attribute("xmlns", prefix, mapping));
        }

        return this;
    }

    /**
     * <p>
     * This will return the URI associated with the supplied
     *   prefix, or an empty <code>String</code> if no such
     *   mapping exists.
     * </p>
     *
     * @param <code>String</code> prefix to locate mapping for.     
     * @return <code>String</code> - URI for supplied prefix.
     */
    public String getNamespaceURI(String prefix) {
        Object o = namespaceMappings.get(prefix);
        if (o != null) {
            return(String)o;
        }
        return "";
    }

    /**
     * <p>
     * This removes a namespace mapping for the supplied prefix.
     * </p>
     *
     * @param <code>String</code> prefix to remove mapping for.
     * @return <code>boolean</code> - whether the mapping was deleted.
     */
    public boolean removeNamespaceMapping(String prefix) {
        Object o = namespaceMappings.remove(prefix);
        if (o != null) {
            return true;
        }
        return false;
    }

    /**
     * <p>
     * This will return all namespace mappings.
     * </p>
     *
     * @return <code>Map</code> - namespace mappings.
     */
    public Map getNamespaceMappings() {
        return namespaceMappings;
    }

    /**
     * <p>
     * This will add a comment to the <code>Document</code>.
     * </p>
     *
     * @param comment <code>Comment</code> to add.
     * @return <code>Document</code> - this object modified.
     */
    public Document addComment(Comment comment) {
        content.add(comment);

        return this;
    }

    /**
     * <p>
     * This will return all content for the <code>Document</code>.
     * </p>
     *
     * @return <code>List</code> - all Document content
     */
    public List getContent() {
        return content;
    }  

}


